# War-Lock
Theme: You work for a company called War-Lock, Hired to detect and diagnose computer infection for the company to remove later.
