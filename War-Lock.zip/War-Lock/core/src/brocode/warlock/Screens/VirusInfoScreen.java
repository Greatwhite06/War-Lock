package brocode.warlock.Screens;

import brocode.warlock.Tools.WorldCreator;


public class VirusInfoScreen {
}
