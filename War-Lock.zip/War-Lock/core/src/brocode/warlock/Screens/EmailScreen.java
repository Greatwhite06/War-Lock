package brocode.warlock.Screens;

public class EmailScreen {
    //add computer startup sound
}
