package brocode.warlock.Screens;

import javax.swing.*;
import java.util.logging.Logger;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JFrame.*;

import javax.swing.JFrame;

public class LoggingScreen {
    //Once activated add computer startup sound

    //Create a frame

    //Optional: what happens when the frame closes

    //create components and put them in a frame

}
